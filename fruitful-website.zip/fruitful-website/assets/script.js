window.dataLayer = window.dataLayer || [];
function gtag() { dataLayer.push(arguments); }
gtag("js", new Date());
gtag("config", "G-PQCCYT6JS8");

const persistParamsToRelevantAnchorElements = (url = window.location.href, links = document.querySelectorAll("a")) => {
  const updated = [];
  const base = new URL(url);
  if (!base.search) return [];

  links.forEach(link => {
    const href = link.getAttribute("href") || "";
    if (href.startsWith("/") || href.includes("fruitful")) {
      const fullUrl = href.startsWith("/") ? new URL(href, base.origin) : new URL(link.href);
      for (const [key, val] of base.searchParams) {
        if (!fullUrl.searchParams.has(key)) fullUrl.searchParams.append(key, val);
      }
      link.href = fullUrl.toString();
      updated.push(link);
    }
  });

  return updated;
};

document.addEventListener("DOMContentLoaded", () => {
  persistParamsToRelevantAnchorElements();
});
